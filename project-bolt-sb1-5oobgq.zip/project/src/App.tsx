import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from 'react-hot-toast';
import { ProductCard } from './components/ProductCard';
import { Cart } from './components/Cart';
import { useCart } from './store/useCart';

const queryClient = new QueryClient();

// Mock data for demonstration
const products = [
  {
    id: 1,
    name: "Fresh Apples",
    price: 2.99,
    description: "Crisp and juicy apples from local farms",
    image: "https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6",
    category: "Fruits"
  },
  {
    id: 2,
    name: "Organic Bananas",
    price: 1.99,
    description: "Sweet and ripe organic bananas",
    image: "https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e",
    category: "Fruits"
  },
  // Add more products as needed
];

function App() {
  const cartItems = useCart((state) => state.items);

  return (
    <QueryClientProvider client={queryClient}>
      <Router>
        <div className="min-h-screen bg-gray-100">
          <nav className="bg-green-600 text-white p-4">
            <div className="container mx-auto flex justify-between items-center">
              <Link to="/" className="text-2xl font-bold">
                FreshBasket
              </Link>
              <Link to="/cart" className="flex items-center gap-2">
                Cart ({cartItems.length})
              </Link>
            </div>
          </nav>

          <main className="container mx-auto py-8 px-4">
            <Routes>
              <Route
                path="/"
                element={
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {products.map((product) => (
                      <ProductCard key={product.id} product={product} />
                    ))}
                  </div>
                }
              />
              <Route path="/cart" element={<Cart />} />
            </Routes>
          </main>
        </div>
        <Toaster position="bottom-right" />
      </Router>
    </QueryClientProvider>
  );
}

export default App;